class Solution {
    public double myPow(double x, int n) {

        if (n == 0) {
            return 1.0;
        }

        long N = n;

        if (N < 0) {
            x = 1.0 / x;
            N = -N;
        }

        double ans = 1.0;

        while (N > 0) {

            if ((N & 1) == 1) {
                ans *= x;
            }

            x *= x;
            N >>= 1;
        }

        return ans;
    }
}